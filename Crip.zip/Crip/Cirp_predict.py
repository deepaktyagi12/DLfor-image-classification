import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, OneHotEncoder
import multiprocessing
import pickle
from Feature_relevance_model import feature_importance
from Rf_prediction_model import RF_model
from svm_prediction_model import svm_model
from xgb_prediction_model import xgb_model
from statistics import mean
import pickle
import xgboost as xgb 

def read_testdata(test_file_path):
    
    data=pd.read_excel(test_file_path)
    
    data['order_date']=pd.to_datetime(data['order_date'])
   
    data['delivery_date']=pd.to_datetime(data['delivery_date'])
    data['user_dob']=pd.to_datetime(data['user_dob'])
    data['user_reg_date']=pd.to_datetime(data['user_reg_date'])
    
    data["order_day"]=data["order_date"].dt.day
    data["order_month"]=data["order_date"].dt.month
    data["order_year"]=data["order_date"].dt.year
    
    data["delivery_day"]=data["delivery_date"].dt.day
    data["delivery_month"]=data["delivery_date"].dt.month
    data["delivery_year"]=data["delivery_date"].dt.year   
   
    data["user_dob_day"]=data["user_dob"].dt.day
    data["user_dob_month"]=data["user_dob"].dt.month
    data["user_dob_year"]=data["user_dob"].dt.year  

    data["user_reg_day"]=data["user_reg_date"].dt.day
    data["user_reg_month"]=data["user_reg_date"].dt.month
    data["user_reg_year"]=data["user_reg_date"].dt.year
     
    data['user_age']     =(data['order_date']-data['user_dob']).astype('timedelta64[D]')
    data['delivery_time']=(data['delivery_date']-data['order_date']).astype('timedelta64[D]')
    data['user_old']     =(data['order_date']-data['user_reg_date']).astype('timedelta64[D]')
    # print(data["user_reg_day"] , data['user_old'])
 
    data=data.drop(['order_date','delivery_date','user_dob','user_reg_date'], axis = 1)
        
    # data = data[data['user_age'] >= 0]
    # data = data[data['delivery_time'] >= 0]
    # data = data[data['user_old'] >= 0]
    ##one hot encoder
    # data=pd.get_dummies(data, columns=['item_size', 'item_color','user_title'])
    data["item_color"] = data["item_color"].astype('category').cat.codes
    data["item_size"] =  data["item_size"].astype('category').cat.codes
    data["user_title"] = data["user_title"].astype('category').cat.codes
    data=data.fillna(0)
    cl=pickle.load(open(r'data/data_encode.pkl','rb'))
    features = cl.transform(data)
    np.nan_to_num(features,copy=True, nan=0.0, posinf=None, neginf=None) 

    print(features.shape)
    
    return features, data['order_item_id']

def main():
    features,order_id_=read_testdata('TestingData_For_Candidate.xlsx')
       
    bst = xgb.Booster({'nthread': 4})  # init model
    bst.load_model('data/test_final_pm_xgb.model')  # load data
    
    dtest = xgb.DMatrix(features)
    ypred = bst.predict(dtest)
    print(len(ypred))
    m1=pickle.load(open(r'data/final_pm_svm.pkl','rb'))
    yp_pred = m1.predict_proba(features)
    print(len(yp_pred))
    
if __name__ == '__main__':

    # Pyinstaller fix
    multiprocessing.freeze_support()

    main()